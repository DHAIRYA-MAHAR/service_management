# Service Booking System

A comprehensive web application for booking local services, built with Django.

## Features

### 1. User Authentication & Roles
- **Registration & Login**: Secure user authentication system.
- **Roles**: 
  - **User**: Can browse services, book appointments, and view booking history.
  - **Provider**: Can list services, manage bookings (Accept/Reject), and view earnings.
  - **Admin**: Superuser access to system-wide analytics.

### 2. Service Management
- Providers can offer services with descriptions, prices, and durations.
- Users can browse available services.

### 3. Booking System
- Users can book services for specific dates and times.
- Double-booking prevention ensures slot availability.
- **Status Workflow**: Pending -> Accepted/Rejected.

### 4. Payments
- Simulated payment gateway for accepted bookings.
- "Pay Now" option appears only after a provider accepts the booking.
- Status updates to "Paid" upon successful transaction.

### 5. Dashboards
- **Provider Dashboard**: Manage incoming requests.
- **User Dashboard**: View booking history and payment status.
- **Admin Analytics**: View platform statistics (Total Users, Providers, Services, Bookings, Revenue).

## Tech Stack
- **Backend**: Django (Python)
- **Frontend**: HTML5, CSS3, Bootstrap 5
- **Database**: SQLite (Default)

## Setup Instructions

1. **Clone the repository**
   ```bash
   git clone <repository_url>
   cd service_booking
   ```

2. **Install Dependencies**
   ```bash
   pip install django
   ```

3. **Apply Migrations**
   ```bash
   python manage.py makemigrations
   python manage.py migrate
   ```

4. **Create Superuser (for Admin access)**
   ```bash
   python manage.py createsuperuser
   ```

5. **Run Server**
   ```bash
   python manage.py runserver
   ```

6. **Access the Application**
   - Home: `http://127.0.0.1:8000/`
   - Admin Panel: `http://127.0.0.1:8000/admin/`

## Usage Guide
- **Register** as a "Provider" to list services.
- **Register** as a "User" to book services.
- **Login** as Superuser to view Analytics.
